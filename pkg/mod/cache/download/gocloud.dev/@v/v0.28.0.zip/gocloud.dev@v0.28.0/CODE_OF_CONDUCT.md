# Code of Conduct

This project is covered under the [Go Code of Conduct][]. In summary:

-   Treat everyone with respect and kindness.
-   Be thoughtful in how you communicate.
-   Don’t be destructive or inflammatory.
-   If you encounter an issue, please mail conduct@golang.org.

[Go Code of Conduct]: https://golang.org/conduct
