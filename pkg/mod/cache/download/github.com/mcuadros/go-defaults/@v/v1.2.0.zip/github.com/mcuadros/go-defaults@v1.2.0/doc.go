/*
This library allow to define a default value to any struct, this is made thanks
to struct tags.
*/
package defaults
