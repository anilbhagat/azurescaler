---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
If applicable provide a small code snippet to reproduce the issue:

**Expected behavior**
A clear and concise description of what you expected to happen.

**Dialect:**

- [ ] postgres 
- [ ] mysql
- [ ] sqlite3 

**Additional context**
Add any other context about the problem here.
