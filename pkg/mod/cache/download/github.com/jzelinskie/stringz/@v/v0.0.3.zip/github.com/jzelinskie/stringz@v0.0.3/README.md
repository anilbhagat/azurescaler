# stringz

[![Go Report Card](https://goreportcard.com/badge/github.com/jzelinskie/stringz?style=flat-square)](https://goreportcard.com/report/github.com/jzelinskie/stringz)
[![Godoc](http://img.shields.io/badge/go-documentation-blue.svg?style=flat-square)](https://godoc.org/github.com/jzelinskie/stringz)
[![LICENSE](https://img.shields.io/github/license/jzelinskie/stringz.svg?style=flat-square)](https://github.com/jzelinskie/stringz/blob/master/LICENSE)

Package stringz provides string manipulations not found in the standard library.
