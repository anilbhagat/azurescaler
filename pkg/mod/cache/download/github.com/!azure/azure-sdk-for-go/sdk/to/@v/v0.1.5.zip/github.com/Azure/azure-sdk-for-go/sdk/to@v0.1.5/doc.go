//go:build go1.13
// +build go1.13

// Copyright 2017 Microsoft Corporation. All rights reserved.
// Use of this source code is governed by an MIT
// license that can be found in the LICENSE file.

// Package to contains various helper type-conversion functions.
package to
