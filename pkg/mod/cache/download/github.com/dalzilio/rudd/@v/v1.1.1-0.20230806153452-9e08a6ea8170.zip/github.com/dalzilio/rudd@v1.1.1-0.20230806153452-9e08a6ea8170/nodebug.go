// Copyright (c) 2021 Silvano DAL ZILIO
//
// MIT License

// +build !debug

package rudd

const _DEBUG bool = false
const _LOGLEVEL int = 0
