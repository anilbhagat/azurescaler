# _integrations/nrecho [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrecho?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrecho)

Package `nrecho` instruments https://github.com/labstack/echo applications.

```go
import "github.com/newrelic/go-agent/_integrations/nrecho"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrecho).
