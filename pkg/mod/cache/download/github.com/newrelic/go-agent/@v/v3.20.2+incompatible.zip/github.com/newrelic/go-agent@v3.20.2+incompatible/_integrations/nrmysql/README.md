# _integrations/nrmysql [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrmysql?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrmysql)

Package `nrmysql` instruments https://github.com/go-sql-driver/mysql.

```go
import "github.com/newrelic/go-agent/_integrations/nrmysql"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrmysql).
