# _integrations/logcontext/nrlogrusplugin [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/logcontext/nrlogrusplugin?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/logcontext/nrlogrusplugin)

Package `nrlogrusplugin` decorates logs for sending to the New Relic backend.

```go
import "github.com/newrelic/go-agent/_integrations/logcontext/nrlogrusplugin"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/logcontext/nrlogrusplugin).
