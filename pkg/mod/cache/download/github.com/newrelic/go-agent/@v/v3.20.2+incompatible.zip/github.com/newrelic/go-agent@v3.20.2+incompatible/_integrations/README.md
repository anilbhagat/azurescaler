The integrations in this directory are for the now deprecated v2 New Relic Go
Agent.  Integrations for the most recent v3 version of the agent can be found
in [v3/integrations](../v3/integrations).
