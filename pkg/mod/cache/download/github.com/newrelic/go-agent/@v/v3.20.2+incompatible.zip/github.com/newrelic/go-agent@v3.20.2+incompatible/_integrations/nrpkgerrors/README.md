# _integrations/nrpkgerrors [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrpkgerrors?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrpkgerrors)

Package `nrpkgerrors` introduces support for https://github.com/pkg/errors.

```go
import "github.com/newrelic/go-agent/_integrations/nrpkgerrors"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrpkgerrors).
