# _integrations/nrgorilla/v1 [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrgorilla/v1?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrgorilla/v1)

Package `nrgorilla` instruments https://github.com/gorilla/mux applications.

```go
import "github.com/newrelic/go-agent/_integrations/nrgorilla/v1"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrgorilla/v1).
