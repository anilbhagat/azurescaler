# _integrations/nrlambda [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrlambda?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrlambda)

Package `nrlambda` adds support for AWS Lambda.

```go
import "github.com/newrelic/go-agent/_integrations/nrlambda"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrlambda).
