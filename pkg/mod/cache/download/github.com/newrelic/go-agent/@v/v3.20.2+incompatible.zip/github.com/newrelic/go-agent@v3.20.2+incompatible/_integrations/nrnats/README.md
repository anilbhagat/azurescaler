# _integrations/nrnats [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrnats?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrnats)

Package `nrnats` instruments https://github.com/nats-io/nats.go.

```go
import "github.com/newrelic/go-agent/_integrations/nrnats"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrnats).
