# _integrations/logcontext [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/logcontext?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/logcontext)

Logs in Context.  Each directory represents a different logging plugin.
Plugins allow you to add the context required to your log messages so you can
see linking in the APM UI.

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/logcontext).
