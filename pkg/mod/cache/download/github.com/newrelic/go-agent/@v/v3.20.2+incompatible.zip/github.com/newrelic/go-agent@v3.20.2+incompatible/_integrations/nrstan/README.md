# _integrations/nrstan [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrstan?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrstan)

Package `nrstan` instruments https://github.com/nats-io/stan.go.

```go
import "github.com/newrelic/go-agent/_integrations/nrstan"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrstan).
