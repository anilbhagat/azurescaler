# _integrations/nrsqlite3 [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrsqlite3?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrsqlite3)

Package `nrsqlite3` instruments https://github.com/mattn/go-sqlite3.

```go
import "github.com/newrelic/go-agent/_integrations/nrsqlite3"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrsqlite3).
