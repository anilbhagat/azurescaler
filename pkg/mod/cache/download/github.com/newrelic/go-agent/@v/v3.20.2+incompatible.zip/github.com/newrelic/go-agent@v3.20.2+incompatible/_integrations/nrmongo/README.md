# _integrations/nrmongo [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrmongo?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrmongo)

Package `nrmongo` instruments https://github.com/mongodb/mongo-go-driver

```go
import "github.com/newrelic/go-agent/_integrations/nrmongo"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrmongo).
