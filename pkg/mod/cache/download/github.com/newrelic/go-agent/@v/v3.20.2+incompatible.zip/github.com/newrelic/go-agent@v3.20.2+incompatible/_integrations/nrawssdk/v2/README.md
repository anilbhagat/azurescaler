# _integrations/nrawssdk/v2 [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrawssdk/v2?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrawssdk/v2)

Package `nrawssdk` instruments https://github.com/aws/aws-sdk-go-v2 requests.

```go
import "github.com/newrelic/go-agent/_integrations/nrawssdk/v2"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrawssdk/v2).
