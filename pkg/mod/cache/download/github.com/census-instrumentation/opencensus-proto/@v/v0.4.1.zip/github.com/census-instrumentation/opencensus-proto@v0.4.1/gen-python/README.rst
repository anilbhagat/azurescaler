OpenCensus Proto
============================================================================

|pypi|

.. |pypi| image:: https://badge.fury.io/py/opencensus-proto.svg
   :target: https://pypi.org/project/opencensus-proto/

Python library generated from OpenCensus cross-language protos.

Installation
------------

::

    pip install opencensus-proto

Usage
-----

.. code:: python

    # TBD
