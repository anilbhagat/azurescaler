// +build !windows

package wincred

func utf16ToByte(...interface{}) []byte {
	return nil
}

func utf16FromString(...interface{}) []uint16 {
	return nil
}
