package java

const notImplementedTpl = `/* NOT YET IMPLEMENTED */`
