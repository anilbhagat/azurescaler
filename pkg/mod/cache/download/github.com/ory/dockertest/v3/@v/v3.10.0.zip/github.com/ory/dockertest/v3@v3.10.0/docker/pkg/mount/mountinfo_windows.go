// Copyright © 2023 Ory Corp
// SPDX-License-Identifier: Apache-2.0

package mount // import "github.com/ory/dockertest/v3/docker/pkg/mount"

func parseMountTable() ([]*Info, error) {
	// Do NOT return an error!
	return nil, nil
}
