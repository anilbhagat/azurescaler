package udpa_data_orca_v1

import (
	xds "github.com/cncf/xds/go/udpa/data/orca/v1" // Note this is cncf/xds
)

type OrcaLoadReport = xds.OrcaLoadReport
