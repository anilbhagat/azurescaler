package server

// Config to set the host and port for different servers
type Config struct {
	Port int
	Host string
}
