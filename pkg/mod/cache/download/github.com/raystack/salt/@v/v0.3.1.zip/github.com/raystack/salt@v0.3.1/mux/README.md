# Mux

`mux` package provides helpers for starting multiple servers. HTTP and gRPC
servers are supported currently.

## Usage

Refer [\_example/](./_example/main.go) for usage reference.
