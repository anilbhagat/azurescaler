# grpcutil

[![GoDoc](https://godoc.org/github.com/authzed/grpcutil?status.svg)](https://godoc.org/github.com/authzed/grpcutil)

grpcutil implements various utilities to simplify common gRPC APIs.
