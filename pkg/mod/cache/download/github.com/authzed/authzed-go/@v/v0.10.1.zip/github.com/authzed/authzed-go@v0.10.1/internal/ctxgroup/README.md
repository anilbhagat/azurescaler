This has been vendored from CockroachDB to avoid large dependencies.
It is made available under the Apache 2.0 License.
https://github.com/cockroachdb/cockroach/blob/126ebfda589553ecb26e0c0bf5b43c4332581465/pkg/util/ctxgroup/ctxgroup.go

When Go modules make it possible to avoid pulling in the entirety of a project for a submodule, this can be removed.
