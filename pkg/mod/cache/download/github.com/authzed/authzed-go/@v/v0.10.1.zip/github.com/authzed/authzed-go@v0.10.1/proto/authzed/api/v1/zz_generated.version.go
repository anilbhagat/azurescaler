package v1

const (
	BufRepository = "buf.build/authzed/api"
	BufTag        = "97ac42fe44d433708249326a5a9580cc59ed9e7f"
)
