<!--
Template relevant to bug reports only!

Keep issue title verbose enough.
-->

**Go version used**:

**What happened**:

**What you expected to happen**:

**How to reproduce it (as minimally and precisely as possible)**:

-->
