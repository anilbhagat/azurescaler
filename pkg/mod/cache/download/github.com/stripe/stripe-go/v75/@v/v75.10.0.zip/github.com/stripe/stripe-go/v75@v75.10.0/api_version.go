//
//
// File generated from our OpenAPI spec
//
//

package stripe

const (
	apiVersion string = "2023-08-16"
)
