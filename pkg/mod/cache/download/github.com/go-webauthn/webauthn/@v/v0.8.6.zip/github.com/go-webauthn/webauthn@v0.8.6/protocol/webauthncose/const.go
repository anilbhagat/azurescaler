package webauthncose

const (
	keyCannotDisplay = "Cannot display key"
)
