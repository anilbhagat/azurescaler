# github.com/go-webauthn/x

Low level packages for [github.com/go-webauthn/webauthn](https://github.com/go-webauthn/webauthn).