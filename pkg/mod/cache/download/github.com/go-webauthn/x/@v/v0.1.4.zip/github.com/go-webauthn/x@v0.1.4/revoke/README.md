# revoke

A fork of [github.com/cloudflare/cfssl/revoke](https://github.com/cloudflare/cfssl/tree/master/revoke) primarily intent 
on implementing functionality needed by [github.com/go-webauthn/webauthn](https://github.com/go-webauthn/webauthn).
